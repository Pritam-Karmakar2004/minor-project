<?php
define('DB_SERVER', 'localhost');
  	define('DB_SERVER_USERNAME', 'root');
  	define('DB_SERVER_PASSWORD', '');
  	define('DB_DATABASE', 'ebilling'); 


  $db_connect=mysqli_connect(DB_SERVER,DB_SERVER_USERNAME,DB_SERVER_PASSWORD,DB_DATABASE) or die("could not connect to DB");
    mysqli_select_db($db_connect,DB_DATABASE)
    or die("could not find DB");      
    date_default_timezone_set("Asia/Calcutta"); 
	
	
	



?>